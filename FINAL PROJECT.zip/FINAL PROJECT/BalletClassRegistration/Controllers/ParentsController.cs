using System;
using System.IO;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using BalletClassRegistration.Data;
using BalletClassRegistration.Models;
using BalletClassRegistration.DTOs;

namespace BalletClassRegistration.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ParentsController : ControllerBase
    {
        private readonly BalletDbContext _context;
        private readonly IWebHostEnvironment _environment;
        
        public ParentsController(BalletDbContext context, IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }
        
        [HttpPost]
        public async Task<ActionResult<Parent>> CreateParent([FromForm] ParentDto parentDto)
        {
            try
            {
                var photoPath = await SavePhotoAsync(parentDto.Photo);
                
                var parent = new Parent
                {
                    FirstName = parentDto.FirstName,
                    LastName = parentDto.LastName,
                    Email = parentDto.Email,
                    Phone = parentDto.Phone,
                    Address = parentDto.Address,
                    City = parentDto.City,
                    PostalCode = parentDto.PostalCode,
                    PhotoPath = photoPath
                };
                
                _context.Parents.Add(parent);
                await _context.SaveChangesAsync();
                
                return CreatedAtAction(nameof(GetParent), new { id = parent.Id }, parent);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while creating the parent: {ex.Message}");
            }
        }
        
        [HttpGet("{id}")]
        public async Task<ActionResult<Parent>> GetParent(int id)
        {
            var parent = await _context.Parents
                .Include(p => p.Children)
                .FirstOrDefaultAsync(p => p.Id == id);
                
            if (parent == null)
            {
                return NotFound();
            }
            
            return parent;
        }
        
        private async Task<string> SavePhotoAsync(IFormFile photo)
        {
            if (photo == null || photo.Length == 0)
            {
                return null;
            }
            
            var uploadsFolder = Path.Combine(_environment.WebRootPath, "uploads", "parents");
            if (!Directory.Exists(uploadsFolder))
            {
                Directory.CreateDirectory(uploadsFolder);
            }
            
            var uniqueFileName = Guid.NewGuid().ToString() + "_" + Path.GetFileName(photo.FileName);
            var filePath = Path.Combine(uploadsFolder, uniqueFileName);
            
            using (var fileStream = new FileStream(filePath, FileMode.Create))
            {
                await photo.CopyToAsync(fileStream);
            }
            
            return $"/uploads/parents/{uniqueFileName}";
        }
    }
}