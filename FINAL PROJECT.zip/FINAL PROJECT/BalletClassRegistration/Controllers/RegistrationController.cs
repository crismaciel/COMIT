using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using BalletClassRegistration.Data;
using BalletClassRegistration.Models;
using BalletClassRegistration.DTOs;

namespace BalletClassRegistration.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RegistrationController : ControllerBase
    {
        private readonly BalletDbContext _context;
        private readonly IWebHostEnvironment _environment;
        
        public RegistrationController(BalletDbContext context, IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }
        
        [HttpPost]
        public async Task<ActionResult<Registration>> Register(RegistrationDto registrationDto)
        {
            using var transaction = await _context.Database.BeginTransactionAsync();
            
            try
            {
                // Check if parent exists
                var parent = await _context.Parents.FindAsync(registrationDto.ParentId);
                if (parent == null)
                {
                    return BadRequest("Parent not found");
                }
                
                // Process child data
                var childPhotoPath = await SavePhotoAsync(registrationDto.Child.Photo, "children");
                
                var child = new Child
                {
                    FirstName = registrationDto.Child.FirstName,
                    LastName = registrationDto.Child.LastName,
                    DateOfBirth = registrationDto.Child.DateOfBirth,
                    Nickname = registrationDto.Child.Nickname,
                    Height = registrationDto.Child.Height,
                    Weight = registrationDto.Child.Weight,
                    FavoriteColor = registrationDto.Child.FavoriteColor,
                    FavoriteCartoonCharacter = registrationDto.Child.FavoriteCartoonCharacter,
                    PhotoPath = childPhotoPath,
                    ParentId = parent.Id
                };
                
                _context.Children.Add(child);
                await _context.SaveChangesAsync();
                
                // Check age eligibility (6-9 years old)
                var age = DateTime.Now.Year - child.DateOfBirth.Year;
                if (DateTime.Now < child.DateOfBirth.AddYears(age)) age--;
                
                if (age < 6 || age > 9)
                {
                    return BadRequest("Child must be between 6 and 9 years old to register for this class.");
                }
                
                // Process registration for each session
                var registrations = new List<Registration>();
                
                foreach (var sessionId in registrationDto.SessionIds)
                {
                    var session = await _context.Sessions.FindAsync(sessionId);
                    if (session == null)
                    {
                        return BadRequest($"Session with ID {sessionId} not found");
                    }
                    
                    if (session.AvailableSpots <= 0)
                    {
                        return BadRequest($"Session on {session.Date.ToShortDateString()} is full");
                    }
                    
                    var registration = new Registration
                    {
                        ChildId = child.Id,
                        SessionId = session.Id,
                        RegistrationDate = DateTime.Now,
                        Status = RegistrationStatus.Pending,
                        Notes = registrationDto.Notes
                    };
                    
                    session.AvailableSpots--;
                    _context.Registrations.Add(registration);
                    registrations.Add(registration);
                }
                
                await _context.SaveChangesAsync();
                
                // Process payment
                if (registrationDto.Payment != null)
                {
                    decimal totalAmount = 150.00m * registrationDto.SessionIds.Length; // $150 per session
                    
                    // In a real application, we would integrate with a payment gateway here
                    // For now, we'll simulate a successful payment
                    
                    foreach (var registration in registrations)
                    {
                        var payment = new Payment
                        {
                            Amount = totalAmount / registrations.Count,
                            PaymentDate = DateTime.Now,
                            Status = PaymentStatus.Completed,
                            Method = PaymentMethod.CreditCard,
                            LastFourDigits = registrationDto.Payment.CardNumber.Substring(registrationDto.Payment.CardNumber.Length - 4),
                            TransactionId = Guid.NewGuid().ToString(),
                            RegistrationId = registration.Id
                        };
                        
                        _context.Payments.Add(payment);
                        
                        // Update registration status
                        registration.Status = RegistrationStatus.Confirmed;
                    }
                    
                    await _context.SaveChangesAsync();
                }
                
                await transaction.CommitAsync();
                
                return Ok(new { Message = "Registration successful", ChildId = child.Id });
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                return StatusCode(500, $"An error occurred during registration: {ex.Message}");
            }
        }
        
        private async Task<string> SavePhotoAsync(IFormFile photo, string folder)
        {
            if (photo == null || photo.Length == 0)
            {
                return null;
            }
            
            var uploadsFolder = Path.Combine(_environment.WebRootPath, "uploads", folder);
            if (!Directory.Exists(uploadsFolder))
            {
                Directory.CreateDirectory(uploadsFolder);
            }
            
            var uniqueFileName = Guid.NewGuid().ToString() + "_" + Path.GetFileName(photo.FileName);
            var filePath = Path.Combine(uploadsFolder, uniqueFileName);
            
            using (var fileStream = new FileStream(filePath, FileMode.Create))
            {
                await photo.CopyToAsync(fileStream);
            }
            
            return $"/uploads/{folder}/{uniqueFileName}";
        }
    }
}