using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace BalletClassRegistration.Models
{
    public class Session
    {
        [Key]
        public int Id { get; set; }
        
        [Required]
        public DateTime Date { get; set; }
        
        [Required]
        public TimeSpan StartTime { get; set; }
        
        [Required]
        public TimeSpan EndTime { get; set; }
        
        [Required]
        public string Location { get; set; }
        
        [Required]
        public int Capacity { get; set; }
        
        [Required]
        public int AvailableSpots { get; set; }
        
        // Navigation property
        public ICollection<Registration> Registrations { get; set; }
        
    }
}