using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace BalletClassRegistration.Models
{
    public class Payment
    {
        [Key]
        public int Id { get; set; }
        
        [Required]
        public Decimal Amount { get; set; }
        
        [Required]
        public DateTime PaymentDate { get; set; }
        
        [Required]
        public PaymentStatus Status { get; set; }
        
        [Required]
        public PaymentMethod Method { get; set; }


        //For credit card payments (stored securely) 
        public string LastFourDigits { get; set; }
        
        //Transaction ID from payment processor
        public string TransactionId { get; set; }

        //Foreign Key
        public int RegistrationId { get; set; }

        // Navigation property
        public Registration Registration { get; set; }
    }
}