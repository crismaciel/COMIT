using System.ComponentModel.DataAnnotations;

namespace BalletClassRegistration.Models
{
    public class Parent
    {
        [Key]
        public int Id { get; set; }
        
        [Required]
        [StringLength(100)]
        public string FirstName { get; set; }
        
        [Required]
        [StringLength(100)]
        public string LastName { get; set; }
        
        [Required]
        [EmailAddress]
        public string Email { get; set; }
        
        [Required]
        [Phone]
        public string Phone { get; set; }
        
        [Required]
        public string Address { get; set; }
        
        [Required]
        public string City { get; set; }
        
        [Required]
        [StringLength(20)]
        public string PostalCode { get; set; }
        
        // Parent's photo stored as path to file
        public string PhotoPath { get; set; }
        
        // Navigation property
        public ICollection<Child> Children { get; set; }
    }
}