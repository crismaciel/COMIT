using System;
using System.ComponentModel.DataAnnotations;

namespace BalletClassRegistration.Models
{
    public class Registration
    {
        [Key]
        public int Id { get; set; }
        
        [Required]
        public DateTime RegistrationDate { get; set; }
        
        [Required]
        public RegistrationStatus Status { get; set; }
        
        // Notes or special requests
        public string Notes { get; set; }
        
        // Foreign keys
        public int ChildId { get; set; }
        public int SessionId { get; set; }
        
        // Navigation properties
        public Child Child { get; set; }
        public Session Session { get; set; }
        public Payment Payment { get; set; }
    }
}