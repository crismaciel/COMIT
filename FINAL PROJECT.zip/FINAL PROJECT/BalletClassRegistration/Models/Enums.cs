namespace BalletClassRegistration.Models
{
    public enum RegistrationStatus
    {
        Pending,
        Confirmed,
        Cancelled,
        Waitlisted,
        Active,
        Inactive
    }
    
    public enum PaymentStatus
    {
        Pending,
        Completed,
        Failed,
        Refunded
    }
    
    public enum PaymentMethod
    {
        CreditCard,
        DebitCard,
        Paypal,
        BankTransfer    
    }
}