using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace BalletClassRegistration.Models
{
    public class Child
    {
        [Key]
        public int Id { get; set; }
        
        [Required]
        [StringLength(100)]
        public string FirstName { get; set; }
        
        [Required]
        [StringLength(100)]
        public string LastName { get; set; }
        
        [Required]
        public DateTime DateOfBirth { get; set; }
        
        // Additional information from questionnaire
        public string Nickname { get; set; }
        
        [Required]
        public double Height { get; set; } // in cm
        
        [Required]
        public double Weight { get; set; } // in kg
        
        public string FavoriteColor { get; set; }
        
        public string FavoriteCartoonCharacter { get; set; }
        
        // Child's photo stored as path to file
        public string PhotoPath { get; set; }
        
        // Foreign key
        public int ParentId { get; set; }
        
        // Navigation properties
        public Parent Parent { get; set; }
        public ICollection<Registration> Registrations { get; set; }
    }
}