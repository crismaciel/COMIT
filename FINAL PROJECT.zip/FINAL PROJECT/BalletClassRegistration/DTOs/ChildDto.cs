using System;
using Microsoft.AspNetCore.Http;

namespace BalletClassRegistration.DTOs
{
    public class ChildDto
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Nickname { get; set; }
        public double Height { get; set; }
        public double Weight { get; set; }
        public string FavoriteColor { get; set; }
        public string FavoriteCartoonCharacter { get; set; }
        public IFormFile Photo { get; set; }
    }
}