namespace BalletClassRegistration.DTOs
{
    public class RegistrationDto
    {
        public int ParentId { get; set; }
        public ChildDto Child { get; set; }
        public int[] SessionIds { get; set; }
        public string Notes { get; set; }
        public PaymentDto Payment { get; set; }
    }
}