using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using BalletClassRegistration.Models;


namespace BalletClassRegistration.Data
{
    public class BalletDbContext : DbContext
    {
        public BalletDbContext(DbContextOptions<BalletDbContext> options) : base(options) { }
        
        public DbSet<Parent> Parents { get; set; }
        public DbSet<Child> Children { get; set; }
        public DbSet<Registration> Registrations { get; set; }
        public DbSet<Session> Sessions { get; set; }
        public DbSet<Payment> Payments { get; set; }
        
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            
            // Configure relationships
            modelBuilder.Entity<Child>()
                .HasOne(c => c.Parent)
                .WithMany(p => p.Children)
                .HasForeignKey(c => c.ParentId);
                
            modelBuilder.Entity<Registration>()
                .HasOne(r => r.Child)
                .WithMany(c => c.Registrations)
                .HasForeignKey(r => r.ChildId);
                
            modelBuilder.Entity<Registration>()
                .HasOne(r => r.Session)
                .WithMany(s => s.Registrations)
                .HasForeignKey(r => r.SessionId);
                
            modelBuilder.Entity<Payment>()
                .HasOne(p => p.Registration)
                .WithOne(r => r.Payment)
                .HasForeignKey<Payment>(p => p.RegistrationId);
                
            // Seed data for sessions
            var sessions = new List<Session>();
            DateTime startDate = new DateTime(2025, 6, 29);
            for (int i = 0; i < 10; i++)
            {
                // Each Sunday
                DateTime sessionDate = startDate.AddDays(i * 7);
                if (sessionDate <= new DateTime(2025, 8, 31))
                {
                    sessions.Add(new Session
                    {
                        Id = i + 1,
                        Date = sessionDate,
                        StartTime = new TimeSpan(10, 30, 0), // 10:30 AM
                        EndTime = new TimeSpan(11, 45, 0),   // 11:45 AM
                        Location = "Studio Room 415, Anvil Centre",
                        Capacity = 20,
                        AvailableSpots = 20
                    });
                }
            }
            
            modelBuilder.Entity<Session>().HasData(sessions);
        }
    }
}